import { RequestHandler } from "express";
import { Alert, AlertsResponse } from "@shared/api";

// Mock alerts data
const mockAlerts: Alert[] = [
  {
    id: "alert_1",
    machineId: "1",
    type: "bearing_wear",
    severity: "high",
    message: "Bearing wear detected - schedule maintenance within 72 hours",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    acknowledged: false,
  },
  {
    id: "alert_2",
    machineId: "2",
    type: "vibration",
    severity: "medium",
    message: "Abnormal vibration pattern detected",
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
    acknowledged: false,
  },
  {
    id: "alert_3",
    machineId: "3",
    type: "overheating",
    severity: "critical",
    message: "Temperature exceeded safe operating limits",
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    acknowledged: true,
  },
];

// Get all alerts
export const getAllAlerts: RequestHandler = async (req, res) => {
  try {
    const { severity, acknowledged, machineId } = req.query;

    let filteredAlerts = [...mockAlerts];

    if (severity) {
      filteredAlerts = filteredAlerts.filter(
        (alert) => alert.severity === severity,
      );
    }

    if (acknowledged !== undefined) {
      const isAcknowledged = acknowledged === "true";
      filteredAlerts = filteredAlerts.filter(
        (alert) => alert.acknowledged === isAcknowledged,
      );
    }

    if (machineId) {
      filteredAlerts = filteredAlerts.filter(
        (alert) => alert.machineId === machineId,
      );
    }

    // Sort by timestamp (newest first)
    filteredAlerts.sort(
      (a, b) =>
        new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime(),
    );

    const response: AlertsResponse = {
      alerts: filteredAlerts,
      totalCount: filteredAlerts.length,
    };

    res.json(response);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch alerts" });
  }
};

// Acknowledge an alert
export const acknowledgeAlert: RequestHandler = async (req, res) => {
  try {
    const { id } = req.params;

    const alertIndex = mockAlerts.findIndex((alert) => alert.id === id);
    if (alertIndex === -1) {
      return res.status(404).json({ error: "Alert not found" });
    }

    mockAlerts[alertIndex].acknowledged = true;

    res.json({ success: true, alert: mockAlerts[alertIndex] });
  } catch (error) {
    res.status(500).json({ error: "Failed to acknowledge alert" });
  }
};
