import { RequestHandler } from "express";
import {
  Machine,
  MachinesResponse,
  MachineDetailsResponse,
  MachineMetrics,
  PredictiveAnalysis,
  Alert,
} from "@shared/api";

// Mock data - replace with real database queries
const mockMachines: Machine[] = [
  {
    id: "1",
    name: "Induction Motor A1",
    type: "induction_motor",
    status: "warning",
    lastUpdated: new Date().toISOString(),
    location: "Production Floor A",
    alertCount: 119,
  },
  {
    id: "2",
    name: "Gear Hobbing Machine B",
    type: "gear_hobbing",
    status: "warning",
    lastUpdated: new Date().toISOString(),
    location: "Production Floor A",
    alertCount: 138,
  },
  {
    id: "3",
    name: "Induction Motor C2",
    type: "induction_motor",
    status: "warning",
    lastUpdated: new Date().toISOString(),
    location: "Assembly Line",
    alertCount: 144,
  },
  {
    id: "5",
    name: "Gear Hobbing Machine A",
    type: "gear_hobbing",
    status: "normal",
    lastUpdated: new Date().toISOString(),
    location: "Production Floor B",
  },
  {
    id: "6",
    name: "Induction Motor D3",
    type: "induction_motor",
    status: "normal",
    lastUpdated: new Date().toISOString(),
    location: "Production Floor C",
  },
  {
    id: "7",
    name: "Gear Hobbing Machine C",
    type: "gear_hobbing",
    status: "normal",
    lastUpdated: new Date().toISOString(),
    location: "Production Floor C",
  },
];

// Generate mock metrics data
function generateMockMetrics(
  machineId: string,
  hours: number = 24,
): MachineMetrics[] {
  const metrics: MachineMetrics[] = [];
  const now = new Date();

  for (let i = 0; i < hours; i++) {
    const timestamp = new Date(now.getTime() - i * 60 * 60 * 1000);
    metrics.push({
      machineId,
      timestamp: timestamp.toISOString(),
      vibration: Math.random() * 200 + 100,
      temperature: Math.random() * 100 + 300,
      motorCurrent: Math.random() * 50 + 100,
<<<<<<< HEAD
      voltage: Math.random() * 50 + 400, // 400-450V typical for industrial motors
=======
      voltage: Math.random() * 50 + 380, // 380-430V typical industrial voltage
>>>>>>> 73703370808db14a6e0e1b97fe52606c525b624f
      rpm: Math.random() * 1000 + 1500,
      pressure: Math.random() * 10 + 15,
    });
  }

  return metrics.reverse(); // Oldest first
}

// Get all machines
export const getAllMachines: RequestHandler = async (req, res) => {
  try {
    const response: MachinesResponse = {
      machines: mockMachines,
    };
    res.json(response);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch machines" });
  }
};

// Get single machine with details
export const getMachineDetails: RequestHandler = async (req, res) => {
  try {
    const { id } = req.params;
    const machine = mockMachines.find((m) => m.id === id);

    if (!machine) {
      return res.status(404).json({ error: "Machine not found" });
    }

    const metrics = generateMockMetrics(id);

    const analysis: PredictiveAnalysis = {
      machineId: id,
      bearingHealth: Math.random() * 20 + 80, // 80-100%
      predictedFailureDate:
        machine.status === "warning"
          ? new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString()
          : undefined,
      maintenanceRecommendations: [
        "Check bearing lubrication",
        "Inspect vibration sensors",
        "Schedule preventive maintenance",
      ],
      anomalyScore:
        machine.status === "warning"
          ? Math.random() * 0.3 + 0.7
          : Math.random() * 0.3,
    };

    const recentAlerts: Alert[] =
      machine.status === "warning"
        ? [
            {
              id: "alert_1",
              machineId: id,
              type: "vibration",
              severity: "medium",
              message: "Elevated vibration levels detected",
              timestamp: new Date().toISOString(),
              acknowledged: false,
            },
          ]
        : [];

    const response: MachineDetailsResponse = {
      machine,
      metrics,
      analysis,
      recentAlerts,
    };

    res.json(response);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch machine details" });
  }
};

// Get real-time metrics for a machine
export const getMachineMetrics: RequestHandler = async (req, res) => {
  try {
    const { id } = req.params;
    const { hours = "24" } = req.query;

    const metrics = generateMockMetrics(id, parseInt(hours as string));

    res.json({
      metrics,
      totalCount: metrics.length,
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch metrics" });
  }
};
