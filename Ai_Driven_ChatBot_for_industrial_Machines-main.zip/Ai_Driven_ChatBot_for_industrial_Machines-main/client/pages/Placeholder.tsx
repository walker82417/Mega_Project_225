import { Link } from "react-router-dom";
import {
  ArrowLeft,
  Settings,
  BarChart3,
  AlertTriangle,
  MessageSquare,
} from "lucide-react";

interface PlaceholderPageProps {
  title: string;
  description: string;
  icon: React.ReactNode;
}

export default function PlaceholderPage({
  title,
  description,
  icon,
}: PlaceholderPageProps) {
  return (
    <div className="bg-background text-foreground p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Link to="/" className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-2xl font-bold">{title}</h1>
        </div>

        {/* Placeholder Content */}
        <div className="bg-card rounded-xl p-12 text-center">
          <div className="text-6xl mb-6 text-muted-foreground">{icon}</div>
          <h2 className="text-2xl font-bold mb-4">{title} Coming Soon</h2>
          <p className="text-muted-foreground mb-8 max-w-md mx-auto">
            {description}
          </p>
          <p className="text-sm text-muted-foreground">
            Continue prompting to add content to this page.
          </p>
        </div>
      </div>
    </div>
  );
}

// Specific placeholder components
export function HistoricalDataPage() {
  return (
    <PlaceholderPage
      title="Historical Data"
      description="View historical machine performance data, trends, and analytics to optimize operations and predict maintenance needs."
      icon={<BarChart3 className="w-16 h-16 mx-auto" />}
    />
  );
}

export function AlertsPage() {
  return (
    <PlaceholderPage
      title="Alerts"
      description="Monitor critical alerts for bearing wear, overheating, abnormal vibrations, and other machine health indicators."
      icon={<AlertTriangle className="w-16 h-16 mx-auto" />}
    />
  );
}

export function SettingsPage() {
  return (
    <PlaceholderPage
      title="Settings"
      description="Configure your user profile, PLC connection settings, cloud integrations, and notification preferences."
      icon={<Settings className="w-16 h-16 mx-auto" />}
    />
  );
}

export function ChatbotPage() {
  return (
    <PlaceholderPage
      title="AI Chatbot"
      description="Full-screen AI assistant for machine health queries, troubleshooting, and maintenance recommendations."
      icon={<MessageSquare className="w-16 h-16 mx-auto" />}
    />
  );
}
