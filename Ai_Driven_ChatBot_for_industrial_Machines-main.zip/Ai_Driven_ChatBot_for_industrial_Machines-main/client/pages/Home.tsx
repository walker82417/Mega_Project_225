import { Link } from "react-router-dom";
import { Factory, BarChart3, Bot, Shield, Zap, Settings } from "lucide-react";

const features = [
  {
    icon: <BarChart3 className="w-8 h-8" />,
    title: "Real-time Monitoring",
    description:
      "Monitor your induction motors and gear hobbing machines in real-time with live data streams.",
  },
  {
    icon: <Bot className="w-8 h-8" />,
    title: "AI-Powered Analytics",
    description:
      "Get intelligent insights and predictive maintenance recommendations powered by AI.",
  },
  {
    icon: <Shield className="w-8 h-8" />,
    title: "Predictive Maintenance",
    description:
      "Prevent failures before they happen with advanced bearing health analysis.",
  },
  {
    icon: <Zap className="w-8 h-8" />,
    title: "Energy Optimization",
    description:
      "Optimize motor performance and reduce energy consumption across your facility.",
  },
];

export default function Home() {
  const isAuthenticated = localStorage.getItem("isAuthenticated");

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6 py-24">
          <div className="text-center">
            <div className="flex items-center justify-center gap-3 mb-6">
              <div className="bg-primary rounded-xl p-4">
                <Factory className="w-12 h-12 text-primary-foreground" />
              </div>
              <h1 className="text-4xl font-bold bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent">
                Industrial Chatbot
              </h1>
            </div>
            <h2 className="text-6xl font-bold text-foreground mb-6 animate-fade-in">
              Smart Machine Monitoring
              <span className="block bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent">
                for Industry 4.0
              </span>
            </h2>
            <p className="text-xl text-muted-foreground mb-8 max-w-3xl mx-auto leading-relaxed animate-fade-in-up">
              Monitor your induction motors and gear hobbing machines with
              real-time data, AI-powered analytics, and predictive maintenance
              capabilities powered by advanced chatbot technology.
            </p>
            <div className="flex gap-4 justify-center">
              {isAuthenticated ? (
                <Link
                  to="/dashboard"
                  className="bg-gradient-to-r from-primary to-blue-600 text-primary-foreground px-10 py-4 rounded-xl font-semibold text-lg hover:from-primary/90 hover:to-blue-600/90 transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
                >
                  Go to Dashboard
                </Link>
              ) : (
                <Link
                  to="/login"
                  className="relative bg-gradient-to-r from-primary to-blue-600 text-primary-foreground px-12 py-5 rounded-xl font-semibold text-lg hover:from-primary/90 hover:to-blue-600/90 transition-all duration-300 shadow-lg hover:shadow-2xl transform hover:-translate-y-2 hover:scale-105 animate-pulse-glow"
                >
                  Get Started
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-6 py-24 relative">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 to-blue-600/5 rounded-3xl"></div>
        <div className="text-center mb-16">
          <h3 className="text-3xl font-bold text-foreground mb-4">
            Everything you need for smart manufacturing
          </h3>
          <p className="text-lg text-muted-foreground">
            Comprehensive monitoring and analytics for your industrial equipment
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-card/80 backdrop-blur-sm rounded-2xl p-8 border border-border hover:border-primary/50 transition-all duration-300 hover:shadow-xl hover:-translate-y-2 group"
            >
              <div className="text-primary mb-6 transform group-hover:scale-110 transition-transform duration-300">
                {feature.icon}
              </div>
              <h4 className="text-xl font-semibold text-foreground mb-3">
                {feature.title}
              </h4>
              <p className="text-muted-foreground">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-gradient-to-r from-card to-card/80 border-t border-border relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/10 via-transparent to-blue-600/10"></div>
        <div className="max-w-7xl mx-auto px-6 py-20 relative z-10">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="group hover:scale-105 transition-transform duration-300">
              <div className="text-5xl font-bold bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent mb-3 animate-number-counter">
                99.9%
              </div>
              <div className="text-foreground font-semibold mb-1">
                Uptime Reliability
              </div>
              <div className="text-muted-foreground">Continuous monitoring</div>
            </div>
            <div className="group hover:scale-105 transition-transform duration-300">
              <div className="text-5xl font-bold bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent mb-3 animate-number-counter">
                24/7
              </div>
              <div className="text-foreground font-semibold mb-1">
                Real-time Data
              </div>
              <div className="text-muted-foreground">Always monitoring</div>
            </div>
            <div className="group hover:scale-105 transition-transform duration-300">
              <div className="text-5xl font-bold bg-gradient-to-r from-primary to-blue-400 bg-clip-text text-transparent mb-3 animate-number-counter">
                AI
              </div>
              <div className="text-foreground font-semibold mb-1">
                Powered Analytics
              </div>
              <div className="text-muted-foreground">Smart predictions</div>
            </div>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <div className="max-w-7xl mx-auto px-6 py-32 text-center relative">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-transparent to-blue-600/5 rounded-3xl"></div>
        <h3 className="text-4xl font-bold text-foreground mb-6 relative z-10">
          Ready to optimize your machines?
        </h3>
        <p className="text-xl text-muted-foreground mb-10 relative z-10">
          Start monitoring your industrial equipment with intelligent chatbot
          analytics today.
        </p>
        {!isAuthenticated && (
          <Link
            to="/login"
            className="relative bg-gradient-to-r from-primary to-blue-600 text-primary-foreground px-12 py-5 rounded-xl font-semibold text-lg hover:from-primary/90 hover:to-blue-600/90 transition-all duration-300 shadow-lg hover:shadow-2xl transform hover:-translate-y-2 hover:scale-105 z-10 inline-block"
          >
            Start Free Trial
          </Link>
        )}
      </div>
    </div>
  );
}
