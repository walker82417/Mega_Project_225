import { useState } from "react";
import { useParams, Link } from "react-router-dom";
import { ArrowLeft, Bot, X, Send } from "lucide-react";
import {
  LineChart,
  Line,
  ResponsiveContainer,
  AreaChart,
  Area,
} from "recharts";

// Mock data for charts
const vibrationData = Array.from({ length: 20 }, (_, i) => ({
  time: 1000 + i * 50,
  value: Math.random() * 200 + 100,
}));

const temperatureData = Array.from({ length: 20 }, (_, i) => ({
  time: `${18 + Math.floor(i / 4)}:${(i % 4) * 15}0`,
  value: Math.random() * 100 + 300,
}));

const motorCurrentData = Array.from({ length: 20 }, (_, i) => ({
  time: i * 500,
  value: Math.random() * 50 + 100,
}));

const voltageData = Array.from({ length: 20 }, (_, i) => ({
  time: `${18 + Math.floor(i / 4)}:${(i % 4) * 15}0`,
  value: Math.random() * 50 + 400, // 400-450V typical for industrial motors
}));

const chatMessages = [
  { role: "user", content: "What is the current machine status?" },
  {
    role: "bot",
    content:
      "The gear hobbing machine is normally within all parameters within optimal ranges.",
  },
];

export default function MachineDetail() {
  const { id } = useParams();
  const [isChatOpen, setIsChatOpen] = useState(true);
  const [message, setMessage] = useState("");
  const [messages, setMessages] = useState(chatMessages);

  const handleSendMessage = () => {
    if (!message.trim()) return;

    setMessages((prev) => [...prev, { role: "user", content: message }]);

    // Simulate bot response
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        {
          role: "bot",
          content:
            "Based on current data analysis, all systems are operating within normal parameters.",
        },
      ]);
    }, 1000);

    setMessage("");
  };

  return (
    <div className="bg-background text-foreground p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Link to="/" className="text-muted-foreground hover:text-foreground">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <h1 className="text-2xl font-bold">Gear Hobbing Machine</h1>
          <div className="ml-auto">
            <button className="bg-card border border-border rounded-lg px-4 py-2 text-sm text-muted-foreground hover:bg-accent">
              System monitor
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Machine Visualization */}
            <div className="bg-card rounded-xl p-6 text-center">
              <div className="relative bg-gradient-to-br from-slate-600 to-slate-800 rounded-xl p-8 mb-4">
                <div className="w-64 h-48 mx-auto bg-gradient-to-br from-gray-400 to-gray-600 rounded-lg flex items-center justify-center">
                  <div className="text-6xl">⚙️</div>
                </div>
                <div className="absolute top-4 left-4 text-white font-semibold">
                  Gear Hobbing Machine
                </div>
              </div>
              <div className="text-2xl font-bold text-success">
                System Normal
              </div>
            </div>

            {/* Charts Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Vibration Chart */}
              <div className="bg-card rounded-xl p-6">
                <h3 className="text-lg font-semibold mb-4">Vibration (mm/s)</h3>
                <div className="text-2xl font-bold mb-2">500</div>
                <div className="h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={vibrationData}>
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="#22c55e"
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>1000</span>
                  <span>1900</span>
                </div>
              </div>

              {/* Temperature Chart */}
              <div className="bg-card rounded-xl p-6">
                <h3 className="text-lg font-semibold mb-4">Temperature (°C)</h3>
                <div className="text-2xl font-bold mb-2">300</div>
                <div className="h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={temperatureData}>
                      <Area
                        type="monotone"
                        dataKey="value"
                        stroke="#3b82f6"
                        fill="#3b82f6"
                        fillOpacity={0.3}
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>18:00</span>
                  <span>19:30</span>
                </div>
              </div>

              {/* Motor Current Chart */}
              <div className="bg-card rounded-xl p-6">
                <h3 className="text-lg font-semibold mb-4">
                  Motor Current (A)
                </h3>
                <div className="text-2xl font-bold mb-2">100</div>
                <div className="h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={motorCurrentData}>
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="#f59e0b"
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>-5:00</span>
                  <span>10:30</span>
                </div>
              </div>

              {/* Voltage Chart */}
              <div className="bg-card rounded-xl p-6">
                <h3 className="text-lg font-semibold mb-4">Voltage (V)</h3>
                <div className="text-2xl font-bold mb-2">425</div>
                <div className="h-32">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={voltageData}>
                      <Line
                        type="monotone"
                        dataKey="value"
                        stroke="#8b5cf6"
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="flex justify-between text-xs text-muted-foreground mt-2">
                  <span>18:00</span>
                  <span>19:30</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Sidebar */}
          <div className="space-y-6">
            {/* Predictive Analysis */}
            <div className="bg-card rounded-xl p-6">
              <h3 className="text-lg font-semibold mb-4">
                Predictive Analysis
              </h3>

              <div className="space-y-4">
                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-muted-foreground">
                      Bearing Health:
                    </span>
                  </div>
                  <div className="text-3xl font-bold text-success">98%</div>
                </div>

                <div>
                  <div className="flex justify-between items-center mb-2">
                    <span className="text-sm text-muted-foreground">
                      Anomaly Alerts:
                    </span>
                  </div>
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-success rounded-full"></div>
                    <div className="w-2 h-2 bg-muted rounded-full"></div>
                    <span className="text-sm ml-2">None</span>
                  </div>
                </div>
              </div>
            </div>

            {/* AI Chatbot */}
            {isChatOpen && (
              <div className="bg-card rounded-xl overflow-hidden">
                <div className="flex items-center justify-between p-4 border-b border-border">
                  <h3 className="font-semibold">Integrated AI Chatbot</h3>
                  <button
                    onClick={() => setIsChatOpen(false)}
                    className="text-muted-foreground hover:text-foreground"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                <div className="p-4">
                  <div className="mb-4">
                    <h4 className="text-sm font-medium mb-2">
                      Chatbot history
                    </h4>

                    <div className="space-y-3 mb-4 max-h-48 overflow-y-auto">
                      {messages.map((msg, i) => (
                        <div key={i} className="flex gap-3">
                          <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
                            {msg.role === "user" ? (
                              "U"
                            ) : (
                              <Bot className="w-4 h-4" />
                            )}
                          </div>
                          <div className="flex-1">
                            <div className="text-sm bg-accent rounded-lg p-3">
                              {msg.content}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Type your message..."
                      className="flex-1 bg-input border border-border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                      onKeyPress={(e) =>
                        e.key === "Enter" && handleSendMessage()
                      }
                    />
                    <button
                      onClick={handleSendMessage}
                      className="bg-primary text-primary-foreground rounded-lg px-3 py-2 hover:bg-primary/90"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* AI Button (when chat is closed) */}
            {!isChatOpen && (
              <button
                onClick={() => setIsChatOpen(true)}
                className="fixed bottom-6 right-6 bg-primary text-primary-foreground rounded-full p-4 shadow-lg hover:bg-primary/90 transition-colors"
              >
                <Bot className="w-6 h-6" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
