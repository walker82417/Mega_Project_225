import { Search, Mic, Bot } from "lucide-react";
import { Link } from "react-router-dom";

interface MachineStatus {
  id: string;
  name: string;
  status: "warning" | "normal";
  alertCount?: number;
  icon: string;
}

const machinesNeedingAttention: MachineStatus[] = [
  {
    id: "1",
    name: "Induction Motor A1",
    status: "warning",
    alertCount: 119,
    icon: "⚡",
  },
  {
    id: "2",
    name: "Gear Hobbing Machine B",
    status: "warning",
    alertCount: 138,
    icon: "⚙️",
  },
  {
    id: "3",
    name: "Induction Motor C2",
    status: "warning",
    alertCount: 144,
    icon: "⚡",
  },
];

const otherMachines: MachineStatus[] = [
  { id: "5", name: "Gear Hobbing Machine A", status: "normal", icon: "⚙️" },
  { id: "6", name: "Induction Motor D3", status: "normal", icon: "⚡" },
  { id: "7", name: "Gear Hobbing Machine C", status: "normal", icon: "⚙️" },
];

function MachineCard({
  machine,
  isWarning = false,
}: {
  machine: MachineStatus;
  isWarning?: boolean;
}) {
  const cardStyles = isWarning
    ? "bg-warning/20 border border-warning/30"
    : "bg-success/10 border border-success/30";

  const statusStyles = isWarning
    ? "bg-warning text-warning-foreground"
    : "bg-success text-success-foreground";

  return (
    <Link
      to={`/machine/${machine.id}`}
      className={`${cardStyles} rounded-2xl p-4 transition-all hover:scale-105 hover:shadow-lg block`}
    >
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-foreground">{machine.name}</h3>
        <span className="text-2xl">{machine.icon}</span>
      </div>

      <div className="flex items-center gap-2">
        {machine.alertCount && (
          <span className="text-warning font-bold text-lg">
            ⚠️ {machine.alertCount}
          </span>
        )}
        <span
          className={`${statusStyles} px-3 py-1 rounded-full text-xs font-medium`}
        >
          {isWarning ? "Warning" : "Normal"}
        </span>
      </div>
    </Link>
  );
}

export default function Dashboard() {
  return (
    <div className="bg-background text-foreground p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Machine Status</h1>
        </div>

        {/* Needs Attention Section */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4 text-warning">
            Needs Attention
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {machinesNeedingAttention.map((machine) => (
              <MachineCard key={machine.id} machine={machine} isWarning />
            ))}
          </div>
        </div>

        {/* Status Indicators */}
        <div className="flex justify-center gap-2 mb-8">
          {[0, 1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className={`w-3 h-3 rounded-full ${
                i === 0 ? "bg-primary" : "bg-muted"
              }`}
            />
          ))}
        </div>

        {/* Other Machines Section */}
        <div className="mb-8">
          <h2 className="text-xl font-semibold mb-4">Other Machines</h2>
          <div className="space-y-3">
            {otherMachines.map((machine) => (
              <MachineCard key={machine.id} machine={machine} />
            ))}
          </div>
        </div>

        {/* Search Bar */}
        <div className="flex items-center gap-4 mt-8">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-muted-foreground w-5 h-5" />
            <input
              type="text"
              placeholder="Search machines..."
              className="w-full bg-card border border-border rounded-2xl pl-12 pr-4 py-4 text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
          <button className="bg-card border border-border rounded-2xl p-4 hover:bg-accent transition-colors">
            <Mic className="w-5 h-5 text-muted-foreground" />
          </button>
          <Link
            to="/chatbot"
            className="bg-primary text-primary-foreground rounded-2xl p-4 hover:bg-primary/90 transition-colors"
          >
            <Bot className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </div>
  );
}
