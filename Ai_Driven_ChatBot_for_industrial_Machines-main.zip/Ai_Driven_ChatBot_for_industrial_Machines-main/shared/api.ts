/**
 * Shared code between client and server
 * Useful to share types between client and server
 * and/or small pure JS functions that can be used on both client and server
 */

/**
 * Example response type for /api/demo
 */
export interface DemoResponse {
  message: string;
}

/**
 * Machine monitoring API types
 */
export interface Machine {
  id: string;
  name: string;
  type: string;
  status: "normal" | "warning" | "error";
  lastUpdated: string;
  location?: string;
  alertCount?: number;
}

export interface MachineMetrics {
  machineId: string;
  timestamp: string;
  vibration: number; // mm/s
  temperature: number; // °C
  motorCurrent: number; // Amperes
  voltage: number; // Volts
  rpm?: number;
  pressure?: number;
}

export interface Alert {
  id: string;
  machineId: string;
  type: "bearing_wear" | "overheating" | "vibration" | "general";
  severity: "low" | "medium" | "high" | "critical";
  message: string;
  timestamp: string;
  acknowledged: boolean;
}

export interface PredictiveAnalysis {
  machineId: string;
  bearingHealth: number; // percentage
  predictedFailureDate?: string;
  maintenanceRecommendations: string[];
  anomalyScore: number;
}

export interface ChatMessage {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: string;
  machineContext?: string;
}

// API Response types
export interface MachinesResponse {
  machines: Machine[];
}

export interface MachineDetailsResponse {
  machine: Machine;
  metrics: MachineMetrics[];
  analysis: PredictiveAnalysis;
  recentAlerts: Alert[];
}

export interface MetricsResponse {
  metrics: MachineMetrics[];
  totalCount: number;
}

export interface AlertsResponse {
  alerts: Alert[];
  totalCount: number;
}

export interface ChatResponse {
  message: ChatMessage;
  suggestions?: string[];
}
